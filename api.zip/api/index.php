<?php

// Include the Database class file
require 'dataabse.php';

// Create an instance of the Database class
$db = new Database();

header("Content-Type: application/json; charset=UTF-8");

$requestMethod = $_SERVER["REQUEST_METHOD"];
$uri = explode('/', parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
if ($uri[1] !== 'api' || $uri[2] !== 'posts') {
    http_response_code(404);
    echo json_encode(['status' => 404 , 'message' => 'Endpoint not found']);
    exit;
}

$postId = $uri[3] ?? null;

switch ($requestMethod) {
    case 'GET':
        if ($postId) {
            getPost($db, $postId);
        } else {
            getPosts($db);
        }
        break;
    case 'POST':
        createPost($db);
        break;
    case 'PUT':
        updatePost($db, $postId);
        break;
    case 'DELETE':
        deletePost($db, $postId);
        break;
    default:
        http_response_code(405);
        echo json_encode(['status' => 405 ,'message' => 'Method not allowed']);
        break;
}

function getPosts($db , $page = 1, $pageSize = 10) {
    try {
       // Ensure $page and $pageSize are valid integers
       $page = is_numeric($page) ? intval($page) : 1;
       $pageSize = is_numeric($pageSize) ? intval($pageSize) : 10;
        
        // Calculate offset
        $offset = ($page - 1) * $pageSize;

        // Call custom select function with pagination
        $posts = $db->select('posts', '*', null, PDO::FETCH_ASSOC, $pageSize, $offset);
        
        // Prepare response
        http_response_code(200);
        echo json_encode([
            'page' => $page,
            'pageSize' => $pageSize,
            'posts' => $posts
        ]);
    } catch (PDOException $e) {
        // Handle database connection or execution errors
        http_response_code(500);
        echo json_encode(['message' => 'Database error: ' . $e->getMessage()]);
    } catch (Exception $e) {
        // Handle general errors
        http_response_code(500);
        echo json_encode(['message' => 'Unexpected error: ' . $e->getMessage()]);
    }
}


function getPost($db, $postId) {
    $post = $db->select('posts', '*', 'id = ' . $postId);
    if ($post) {
        echo json_encode($post[0]);
    } else {
        http_response_code(404);
        echo json_encode(['status' => 404 , 'message' => 'Post not found']);
    }
}

function createPost($db) {
    try {
        $data = json_decode(file_get_contents('php://input'), true);
        
        // Validate required fields
        if (!isset($data['title'], $data['content'], $data['author']) ||
            !is_string($data['title']) || 
            !is_string($data['content']) || 
            !is_string($data['author']) ||
            trim($data['title']) === '' || 
            trim($data['author']) === '') {
            http_response_code(400);
            echo json_encode(['status' => 400,'message' => 'Invalid input: Missing or incorrect data type for required fields']);
            return;
        }
        
        // Insert data into the database
        $insertData = [
            'title' => $data['title'],
            'content' => $data['content'],
            'author' => $data['author']
        ];
        if ($db->insert('posts', $insertData)) {
            http_response_code(201);
            echo json_encode(['status' => 201 , 'id' => $db->pdo->lastInsertId(), 'message' => 'Post created']);
        } else {
            http_response_code(500);
            echo json_encode(['status' => 500 ,'message' => 'Failed to create post']);
        }
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['status' => 500 ,'message' => 'Database error: ' . $e->getMessage()]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['status' => 500 , 'message' => 'Unexpected error: ' . $e->getMessage()]);
    }
}

function updatePost($db, $postId) {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!isset($postId) || !is_numeric($postId)) {
        http_response_code(400);
        echo json_encode(['status' => 400, 'message' => 'Invalid post ID']);
        return;
    }
    $updateData = [];
    foreach ($data as $key => $value) {
        $updateData[$key] = $value;
    }
    if ($db->update('posts', $updateData, 'id = ' . $postId)) {
        echo json_encode(['status' => 200 , 'message' => 'Post updated']);
    } else {
        http_response_code(404);
        echo json_encode(['status' => 404 , 'message' => 'Post not found']);
    }
}

function deletePost($db, $postId) {
    try {
        if ($db->delete('posts', 'id = ' . $postId)) {
            http_response_code(200);
            echo json_encode([ 'status' => 202 , 'message' => 'Post deleted']);
        } else {
            http_response_code(404);
            echo json_encode(['status' => 404 , 'message' => 'Post not found']);
        }
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['message' => 'Database error: ' . $e->getMessage()]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['message' => 'Unexpected error: ' . $e->getMessage()]);
    }
}

?>
