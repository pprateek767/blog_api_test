<?php
    return [
        'host' => 'localhost',
        'dbname' => 'dev_tes',
        'username' => 'root',
        'password' => ''
    ];
?>